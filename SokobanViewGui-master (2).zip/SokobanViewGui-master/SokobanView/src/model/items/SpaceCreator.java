package model.items;

public class SpaceCreator implements ICreator {

	public Items create() {

		return new Space();
	}

}
