package model.items;

public class DestinationCreator implements ICreator {


	public Items create() {
		
		return new Destination_Box()  ;
	}

}
