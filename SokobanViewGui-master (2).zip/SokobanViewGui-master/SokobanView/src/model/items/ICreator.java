package model.items;

public interface ICreator {
	public Items create();

}
