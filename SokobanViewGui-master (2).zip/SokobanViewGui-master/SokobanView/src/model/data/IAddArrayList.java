package model.data;

import model.items.Items;

public interface IAddArrayList {
	public void addToArrayList(Level level,Items item);

}
