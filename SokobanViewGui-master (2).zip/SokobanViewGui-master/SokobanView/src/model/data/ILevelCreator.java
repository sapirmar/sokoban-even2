package model.data;

public interface ILevelCreator {
	
	public Level create(String in);//function that get the path and create level
}
