package controller.command;

public interface ICommand {
public void execute();
}
